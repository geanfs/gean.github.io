package br.edu.ifrn.crudlivros.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.edu.ifrn.crudlivros.dominio.Livro;



public interface LivroRepository extends JpaRepository<Livro, Integer>{

		/**
		 * 
		 * @param nome selecionado do Banco de Dados
		 * @param autor  selecionado do Banco de Dados
		 */
		@Query("select l from Livro l where  l.nome like %:nome% " +
		        "and l.autor like %:autor% ")
		List<Livro> findByAutorAndNome(@Param ("nome") String nome,
									@Param ("autor") String autor);
	}

