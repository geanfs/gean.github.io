package br.edu.ifrn.crudlivros.controladores;
import br.edu.ifrn.crudlivros.dominio.Arquivo;
import br.edu.ifrn.crudlivros.dominio.Usuario;
import br.edu.ifrn.crudlivros.repository.ArquivoRepository;
import br.edu.ifrn.crudlivros.repository.UsuarioRepository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


/**
 * 
 * @author PALOMA, GEAN E VITORIA
 *
 */
@Controller
@RequestMapping("/usuarios")
public class CadastroUsuarioController {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
	private ArquivoRepository arquivoRepository;

	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("usuario", new Usuario());
		return "usuario/cadastro";
		
	}
	/**
	 * 
	 * @param usuario Pega o atributo usuario da classe Usuario
	 * @param result Erros na hora de cadastro
	 * @param attr Mensagem de sucesso quando cadastrado corretamente
	 * @param arquivo Pega o atributo arquivo da classe Arquivo para salvar a foto do usuario
	 * @param sessao Obtem as informa��es salvas no BD, usuario e arquivo
	 * @return retorna pra pagina de cadastroo
	 */
	
	@PostMapping("/salvar")
	@Transactional(readOnly = false)
	public String salvar(@Valid Usuario usuario, BindingResult result, ModelMap model, RedirectAttributes attr,
			@RequestParam("file") MultipartFile arquivo,
			HttpSession sessao) {
		try {
			
			if(arquivo != null && !arquivo.isEmpty()) {
				//Normaliza o nome do arquivo
				String nomeArquivo =
						StringUtils.cleanPath(arquivo.getOriginalFilename());
				Arquivo arquivoBD = new Arquivo(null, nomeArquivo, arquivo.getContentType(), arquivo.getBytes());
			
				//salvando a foto no banco de dados
				arquivoRepository.save(arquivoBD);
			
				if(usuario.getFoto() != null && usuario.getFoto().getId()!= null && usuario.getFoto().getId() > 0) {
					arquivoRepository.delete(usuario.getFoto());
				}
				usuario.setFoto(arquivoBD);
				
			}else {
				usuario.setFoto(null);
			}
			
			if(result.hasErrors()) { 
				return "usuario/cadastro";
			}
			
			//Criptografando a senha
			String senhaCriptografada = 
					new BCryptPasswordEncoder().encode(usuario.getSenha()); 
			usuario.setSenha(senhaCriptografada);
			
			//Cadastro e edicao
			usuarioRepository.save(usuario);
			attr.addFlashAttribute("msgSucesso", "Opera��o realizada com sucesso!");
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	 
		
		return "redirect:/usuarios/cadastro";
	}
	/**
	 * 
	 * @param idUsuario pega o id do usuario para fazer edi��o
	 * @param model usuario sera igual ao usuario editado 
	 * @param sessao pega o usuario do BD
	 * @return retorna para pagina de cadastro
	 */
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/editar/{id}")
	public String iniciarEdicao(@PathVariable("id") Integer idUsuario,
			ModelMap model,
			HttpSession sessao
	
	) {
		
		Usuario u = usuarioRepository.findById(idUsuario).get();
		
		model.addAttribute("usuario",u);
	
	return "/usuario/cadastro";
	
	}
	
	
	
	/**
	 * 
	 * @return retorna a Bibliotecario e Usuario para ser escolhido na edi��o
	 */
	@ModelAttribute("funcao")
	public List<String> getFuncao(){
		return Arrays.asList("Bibliotecario", "Usuario");
		
	}
	
	
}
