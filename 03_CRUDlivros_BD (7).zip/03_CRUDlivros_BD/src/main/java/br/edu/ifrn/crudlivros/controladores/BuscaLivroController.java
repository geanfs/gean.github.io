package br.edu.ifrn.crudlivros.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crudlivros.dominio.Livro;
import br.edu.ifrn.crudlivros.repository.LivroRepository;

@Controller
@RequestMapping("/livros") //url para bbusca de livros
public class BuscaLivroController {
	@Autowired
	private LivroRepository livroRepository;

	/**
	 * 
	 * @return busca de livros
	 */
	@GetMapping("/busca")
	public String entrarBusca() {
		return "livros/busca";
	}
	
	/**
	 * 
	 * @param nome 
	 * @param autor
	 * @param mostrarTodosDados 
	 * @param sessao
	 * @param model 
	 * @return
	 */
	@GetMapping("/buscar")
	public String buscar(@RequestParam(name="nome", required=false)String nome,
			@RequestParam(name="autor", required=false)String autor,
			@RequestParam(name="mostrarTodosDados",required=false) 
			Boolean mostrarTodosDados,
			HttpSession sessao,
			ModelMap model
			) {
		
		List<Livro> livrosEncontrados = livroRepository.findByAutorAndNome(nome, autor);
		
		model.addAttribute("livrosEncontrados", livrosEncontrados);
		
		if (mostrarTodosDados != null) {
			model.addAttribute("mostrarTodosDados", true);
		}
		
		
		return "livros/busca";
	} 
	
	
	/**
	 * 	
	 * @param idLivro
	 * @param sessao
	 * @param attr
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping("/remover/{id}")
	public String remover(@PathVariable("id") Integer idLivro,
			HttpSession sessao,
			RedirectAttributes attr) {
		
		livroRepository.deleteById(idLivro);
		attr.addFlashAttribute("msgSucesso", "Livro removido com sucesso!");
		
		
		return "redirect:/livros/buscar";
	}
	
	
	
}


