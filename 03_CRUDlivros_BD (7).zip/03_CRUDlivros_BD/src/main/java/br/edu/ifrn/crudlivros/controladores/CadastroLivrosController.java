package br.edu.ifrn.crudlivros.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crudlivros.DTO.AutocompleteDTO;
import br.edu.ifrn.crudlivros.dominio.Genero;
import br.edu.ifrn.crudlivros.dominio.Livro;
import br.edu.ifrn.crudlivros.repository.GeneroRepository;
import br.edu.ifrn.crudlivros.repository.LivroRepository;
import br.edu.ifrn.crudlivros.repository.UsuarioRepository;

@Controller
@RequestMapping("/livros")//para acessar as url dessa classe primeiro deve colocar o texto /livros
public class CadastroLivrosController {
	
	@Autowired
	private LivroRepository livroRepository;
	
	@Autowired
	private GeneroRepository generoRepository;
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/cadastro")//endereço da extensão
	public String entrarCadastro(ModelMap model){
		model.addAttribute("livro", new Livro());
		return "livros/cadastro";
	}
	/**
	 * 
	 * @param livro
	 * @param result
	 * @param model
	 * @param attr
	 * @param sessao
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping("/salvar")
	public String salvar (@Valid Livro livro, BindingResult result, ModelMap model, RedirectAttributes attr, HttpSession sessao) {
		
		
	if(result.hasErrors()) {
		return "livros/cadastro";
	}
		
	//Cadastro e edicao
			livroRepository.save(livro);
			attr.addFlashAttribute("msgSucesso", "Opera��o realizada com sucesso!");
	
		return"redirect:/livros/cadastro";
	}
	
	/**
	 * 
	 * @param idLivro
	 * @param model
	 * @param sessao
	 * @return
	 */
	@GetMapping("/editar/{id}")
	public String iniciarEdicao(@PathVariable("id") Integer idLivro,
			ModelMap model,
			HttpSession sessao) {
		
		Livro l = livroRepository.findById(idLivro).get();
		
		model.addAttribute("livro", l);
		
		
		return "/livros/cadastro";
	}
	/**
	 * 
	 * @param termo
	 * @return
	 */
	@GetMapping("/autocompleteGeneros")
	@org.springframework.transaction.annotation.Transactional(readOnly = true)
	@ResponseBody
	public List<AutocompleteDTO> autocompletGeneros(
			@RequestParam("term") String termo){
		List<Genero> generos = generoRepository.findByNome(termo);
		
		List<AutocompleteDTO> resultados = new ArrayList<>();
		
		generos.forEach(g -> resultados.add(
				new AutocompleteDTO(g.getNome(), g.getId())
				));
		return resultados;
		
	}
}
