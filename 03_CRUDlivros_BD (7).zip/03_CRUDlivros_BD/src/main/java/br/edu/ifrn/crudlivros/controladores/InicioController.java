package br.edu.ifrn.crudlivros.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InicioController {
	
	/**
	 * 
	 * @return retorna para pagina de inicio
	 */
	@GetMapping("/") //url pra acessar a pagina, usada quando for usar direto do navegador
	public String inicio() { //nome da pagina que vai ser carregada
		return "inicio";
	}
	
	@GetMapping("/login") 
	public String login() { 
		return "login";
	}
	
	/**
	 * 
	 * @param model parametro de mesagem de erro, para o caso do usuario digitar dados incorretos
	 * @return se os dados estiveres errados retorna para pagina de login
	 */
	@GetMapping("/login-error") 
	public String loginError(ModelMap model ) { 
		model.addAttribute("msgErro","Login ou senha incorreta. Tente novamente");
		return "login";
	}
}
