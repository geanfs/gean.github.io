package br.edu.ifrn.crudlivros.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifrn.crudlivros.dominio.Arquivo;

public interface ArquivoRepository extends JpaRepository<Arquivo, Long >{

	//nao � necessario implementar metodos, os utilizados sao implementados pelo proprio spring//
}
